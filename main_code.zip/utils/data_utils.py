import csv
from pathlib import Path
import pandas as pd
import numpy as np
import os

def save_result_to_csv(result, filename):
    file_path = Path(filename)
    file_exists = file_path.exists()
    row = {
        'function': result.get('function'),
        'k_samples': result.get('k_samples_used', result.get('k_samples', None)),
        'p_threshold': result.get('p_threshold_used', result.get('p_threshold', None)),
        'epsilon': result.get('epsilon_used', result.get('epsilon', None)),
        'seed': result.get('seed'),
        'simple_regret': result.get('simple_regret'),
        'cumulative_regret': result.get('cumulative_regret'),
        'n_evaluations': result.get('n_evaluations'),
        'total_time': sum(result.get('iteration_history', {}).get('time', [])),
        'best_value': result.get('best_y'),
        'final_domain_size': result.get('final_domain_size', 0)
    }
    file_path.parent.mkdir(parents=True, exist_ok=True)
    with open(file_path, 'a', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=row.keys())
        if not file_exists:
            writer.writeheader()
        writer.writerow(row)

def load_results_from_csv(filename):
    file_path = Path(filename)
    if not file_path.exists():
        return {}
    df = pd.read_csv(file_path)
    grouped = {}
    for _, row in df.iterrows():
        func = row['function']
        k = int(row['k_samples']) if not pd.isna(row['k_samples']) else None
        p = float(row['p_threshold']) if not pd.isna(row['p_threshold']) else None
        eps = float(row['epsilon']) if not pd.isna(row['epsilon']) else None
        config_key = f"{func}_K{k}_P{p:.1f}_E{eps:.2f}"
        if config_key not in grouped:
            grouped[config_key] = {
                'config': {'k_samples': k, 'p_threshold': p, 'epsilon': eps, 'function': func},
                'regrets': [],
                'times': [],
                'n_evals': []
            }
        grouped[config_key]['regrets'].append(float(row['simple_regret']))
        grouped[config_key]['times'].append(float(row['total_time']))
        grouped[config_key]['n_evals'].append(int(row['n_evaluations']))
    results = {}
    for key, data in grouped.items():
        regrets = np.array(data['regrets'])
        times = np.array(data['times'])
        results[key] = {
            'config': data['config'],
            'stats': {
                'simple_regret_mean': np.mean(regrets),
                'simple_regret_std': np.std(regrets),
                'simple_regret_min': np.min(regrets),
                'simple_regret_max': np.max(regrets),
                'time_mean': np.mean(times),
                'time_std': np.std(times),
                'n_seeds': len(regrets),
                'n_evaluations': int(np.mean(data['n_evals'])),
                'all_regrets': regrets
            }
        }
    return results

def create_result_directories(base_path='results'):
    os.makedirs(base_path, exist_ok=True)
    subdirs = ['ablation', 'comparison', 'ml_experiment']
    for s in subdirs:
        os.makedirs(os.path.join(base_path, s, 'plots'), exist_ok=True)
