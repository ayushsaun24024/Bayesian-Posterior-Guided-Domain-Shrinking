import numpy as np

def discretize_domain(bounds, grid_size):
    dimension = len(bounds)
    grids = [np.linspace(low, high, grid_size) for low, high in bounds]
    mesh = np.meshgrid(*grids, indexing='ij')
    domain_points = np.stack(mesh, axis=-1).reshape(-1, dimension)
    return domain_points

def sample_random_points(domain_points, n_samples):
    n_points = domain_points.shape[0]
    random_indices = np.random.choice(n_points, size=n_samples, replace=True)
    return domain_points[random_indices].copy()

def generate_random_domain(bounds, n_points, rng=None):
    if rng is None:
        rng = np.random
    dims = len(bounds)
    samples = np.zeros((n_points, dims))
    for i, (low, high) in enumerate(bounds):
        samples[:, i] = rng.uniform(low, high, size=n_points)
    return samples
