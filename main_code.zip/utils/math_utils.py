import numpy as np
from scipy.linalg import cholesky
from scipy import stats as scipy_stats

def set_seed(seed=None):
    if seed is None:
        seed = 42
    np.random.seed(seed)

def rbf_kernel(x1, x2, length_scale, variance):
    x1 = np.atleast_2d(x1)
    x2 = np.atleast_2d(x2)
    from scipy.spatial.distance import cdist
    dists_sq = cdist(x1, x2, metric='sqeuclidean')
    K = variance * np.exp(-dists_sq / (2 * length_scale**2))
    if x1.shape == x2.shape and np.allclose(x1, x2):
        K += 1e-8 * np.eye(K.shape[0])
    return K

def compute_information_gain(K_matrix, tau):
    n = K_matrix.shape[0]
    if tau > 0:
        sign, logdet = np.linalg.slogdet(np.eye(n) + (1.0 / tau) * K_matrix)
        gamma = 0.5 * logdet if sign > 0 else 0.0
    else:
        sign, logdet = np.linalg.slogdet(K_matrix + 1e-8 * np.eye(n))
        gamma = 0.5 * logdet if sign > 0 else 0.0
    return gamma

def compute_beta_n(B, gamma_n, delta):
    beta_n = 2 * (B ** 2) + 2 * gamma_n + 4 * np.log(2.0 / delta)
    return beta_n

def compute_ucb(mu, sigma, beta_sqrt):
    return mu + beta_sqrt * sigma

def compute_lcb(mu, sigma, beta_sqrt):
    return mu - beta_sqrt * sigma

def sample_gp_posterior_cholesky(gp_model, X_domain, n_samples, use_cholesky=True):
    X_domain = np.atleast_2d(X_domain)
    n_points = X_domain.shape[0]
    mu, sigma = gp_model.predict(X_domain, return_std=True)
    K = gp_model.get_kernel_matrix(X_domain)
    jitter = 1e-6
    K_stable = K + jitter * np.eye(n_points)
    if use_cholesky:
        try:
            L = cholesky(K_stable, lower=True)
            z = np.random.randn(n_samples, n_points)
            samples = mu[np.newaxis, :] + z @ L.T
            return samples
        except np.linalg.LinAlgError:
            use_cholesky = False
    if not use_cholesky:
        eigvals, eigvecs = np.linalg.eigh(K_stable)
        eigvals = np.maximum(eigvals, 1e-10)
        L = eigvecs @ np.diag(np.sqrt(eigvals))
        z = np.random.randn(n_samples, n_points)
        samples = mu[np.newaxis, :] + z @ L.T
        return samples

def compute_posterior_probability(samples, epsilon, f_max_samples=None):
    n_samples, n_points = samples.shape
    if f_max_samples is None:
        f_max_samples = np.max(samples, axis=1)
    threshold = f_max_samples[:, np.newaxis] - epsilon
    indicators = (samples >= threshold).astype(float)
    posterior_probs = np.mean(indicators, axis=0)
    return posterior_probs

def compute_posterior_statistics(posterior_probs):
    return {
        'mean': np.mean(posterior_probs),
        'std': np.std(posterior_probs),
        'min': np.min(posterior_probs),
        'max': np.max(posterior_probs),
        'median': np.median(posterior_probs),
        'q25': np.percentile(posterior_probs, 25),
        'q75': np.percentile(posterior_probs, 75)
    }

def compute_entropy(posterior_probs):
    probs_clipped = np.clip(posterior_probs, 1e-10, 1.0)
    entropy = -np.sum(probs_clipped * np.log(probs_clipped)) / len(probs_clipped)
    return entropy

def compute_confidence_intervals(regrets, confidence=0.95):
    if len(regrets) < 2:
        return {
            'mean': np.mean(regrets),
            'ci_lower': np.mean(regrets),
            'ci_upper': np.mean(regrets),
            'margin_of_error': 0.0,
            'std_error': 0.0
        }
    mean = np.mean(regrets)
    std_err = scipy_stats.sem(regrets)
    margin = std_err * scipy_stats.t.ppf((1 + confidence) / 2, len(regrets) - 1)
    return {
        'mean': mean,
        'ci_lower': mean - margin,
        'ci_upper': mean + margin,
        'margin_of_error': margin,
        'std_error': std_err
    }

def bootstrap_confidence_interval(data, n_bootstrap=1000, ci=0.95):
    bootstrap_means = []
    for _ in range(n_bootstrap):
        bootstrap_sample = np.random.choice(data, size=len(data), replace=True)
        bootstrap_means.append(np.mean(bootstrap_sample))
    bootstrap_means = np.array(bootstrap_means)
    lower_percentile = (1 - ci) / 2 * 100
    upper_percentile = (1 + ci) / 2 * 100
    return {
        'ci_lower': np.percentile(bootstrap_means, lower_percentile),
        'ci_upper': np.percentile(bootstrap_means, upper_percentile),
        'bootstrap_mean': np.mean(bootstrap_means),
        'bootstrap_std': np.std(bootstrap_means)
    }

def compute_adaptive_threshold_information_theoretic(posterior_probs, k_factor=0.5):
    if len(posterior_probs) == 0:
        return 0.0
    mu_p = np.mean(posterior_probs)
    sigma_p = np.std(posterior_probs)
    threshold = mu_p + k_factor * sigma_p
    threshold = np.clip(threshold, 0.0, 1.0)
    return threshold
