import numpy as np
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import RBF, ConstantKernel

class GaussianProcessSurrogate:
    def __init__(self, length_scale=None, variance=None, noise_level=None, random_state=None):
        if length_scale is None:
            length_scale = 1.0
        if variance is None:
            variance = 1.0
        if noise_level is None:
            noise_level = 0.0
        kernel = ConstantKernel(variance) * RBF(length_scale)
        alpha = noise_level if noise_level > 0 else 1e-10
        self.gp = GaussianProcessRegressor(kernel=kernel, alpha=alpha, n_restarts_optimizer=5, normalize_y=False, random_state=random_state)
        self.X_train = None
        self.y_train = None
        self.is_fitted = False

    def fit(self, X, y):
        X = np.atleast_2d(X)
        y = np.asarray(y).ravel()
        if X.shape[0] != y.shape[0]:
            if X.shape[0] == 1 and y.shape[0] > 1:
                X = X.T
            else:
                raise ValueError("Shape mismatch between X and y")
        self.X_train = X.copy()
        self.y_train = y.copy()
        self.gp.fit(X, y)
        self.is_fitted = True

    def predict(self, X, return_std=True):
        if not self.is_fitted:
            raise RuntimeError("GP model must be fitted before prediction")
        X = np.atleast_2d(X)
        if return_std:
            mu, sigma = self.gp.predict(X, return_std=True)
            return mu, sigma
        else:
            mu = self.gp.predict(X, return_std=False)
            return mu

    def get_kernel_matrix(self, X):
        X = np.atleast_2d(X)
        return self.gp.kernel_(X)
