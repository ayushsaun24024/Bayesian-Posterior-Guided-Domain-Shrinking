import numpy as np
from pathlib import Path
from utils.gp_surrogate import GaussianProcessSurrogate
from utils.domain import generate_random_domain, sample_random_points
from utils.math_utils import compute_ucb, compute_lcb, compute_beta_n, compute_information_gain, set_seed
from utils.data_utils import save_result_to_csv

class REDSOptimizer:
    def __init__(self, func, bounds, config, seed=None):
        self.func = func
        self.bounds = bounds
        self.config = config
        self.seed = seed
        set_seed(seed)
        self.random = np.random.RandomState(seed)
        self.gp = GaussianProcessSurrogate(length_scale=config.get('notebook_defaults', {}).get('gp_length_scale', 1.0),
                                           variance=config.get('notebook_defaults', {}).get('gp_signal_variance', 1.0),
                                           noise_level=config.get('optimization', {}).get('noise_std', 0.0),
                                           random_state=seed)
        self.domain = None
        self.X_obs = []
        self.y_obs = []
        self.best_x = None
        self.best_y = -np.inf
        self.history = {'simple_regret': [], 'cumulative_regret': [], 'domain_sizes': []}
        self.beta_sqrt = 1.0

    def initialize_domain(self, n_points):
        self.domain = generate_random_domain(self.bounds, n_points, rng=self.random)

    def initial_evaluations(self, n_initial):
        points = sample_random_points(self.domain, n_initial)
        for x in points:
            y = float(self.func(x))
            self.X_obs.append(x)
            self.y_obs.append(y)
            if y > self.best_y:
                self.best_y = y
                self.best_x = x

    def update_gp(self):
        X = np.array(self.X_obs)
        y = np.array(self.y_obs)
        self.gp.fit(X, y)

    def compute_beta(self):
        K = self.gp.get_kernel_matrix(np.atleast_2d(self.domain))
        gamma = compute_information_gain(K, self.config.get('optimization', {}).get('tau', 0.2))
        beta = compute_beta_n(self.config.get('optimization', {}).get('B', 1.0), gamma, self.config.get('optimization', {}).get('delta', 0.1))
        self.beta_sqrt = np.sqrt(beta)

    def select_next(self, n_candidates=1):
        mu, sigma = self.gp.predict(self.domain, return_std=True)
        ucb = compute_ucb(mu, sigma, self.beta_sqrt)
        idx = np.argmax(ucb)
        return self.domain[idx], idx

    def shrink_domain(self, posterior_probs, k_factor):
        threshold = np.percentile(posterior_probs, 100.0 * (1.0 - k_factor))
        mask = posterior_probs >= threshold
        if np.sum(mask) < 1:
            mask = np.ones_like(mask, dtype=bool)
        self.domain = self.domain[mask]

    def run(self, n_iterations, n_initial=5, domain_size=1000, k_factor=0.5, save_file=None, seed=None):
        if seed is not None:
            set_seed(seed)
        self.initialize_domain(domain_size)
        self.initial_evaluations(n_initial)
        self.update_gp()
        for it in range(n_iterations):
            self.compute_beta()
            x_next, idx = self.select_next()
            y_next = float(self.func(x_next))
            self.X_obs.append(x_next)
            self.y_obs.append(y_next)
            if y_next > self.best_y:
                self.best_y = y_next
                self.best_x = x_next
            self.update_gp()
            simple_regret = np.abs(self.best_y - self.best_y)
            cumulative = np.sum(np.maximum(0.0, np.max(self.y_obs) - np.array(self.y_obs)))
            self.history['simple_regret'].append(simple_regret)
            self.history['cumulative_regret'].append(cumulative)
            self.history['domain_sizes'].append(len(self.domain))
        result = {
            'function': self.config.get('current_function', 'unknown'),
            'seed': self.seed,
            'best_x': self.best_x,
            'best_y': self.best_y,
            'simple_regret': self.history['simple_regret'],
            'cumulative_regret': self.history['cumulative_regret'],
            'final_domain_size': len(self.domain),
            'iteration_history': self.history
        }
        if save_file:
            Path(save_file).parent.mkdir(parents=True, exist_ok=True)
            save_result_to_csv(result, save_file)
        return result
