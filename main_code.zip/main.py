import yaml
from experiments import ablation_study, reds_vs_v2, ml_experiment
from visualization import convergence_plots, advanced_plots
import os

def load_config():
    with open('config.yaml', 'r') as f:
        return yaml.safe_load(f)

def main():
    config = load_config()
    print("BML Project: Bayesian Optimization Experiments")
    print("="*80)
    print("\n1. Running v2 Ablation Study...")
    try:
        ablation_study.run_ablation_study(config)
        ablation_study.analyze_ablation_results(config)
    except Exception as e:
        print("Ablation study failed:", e)
    print("\n2. Running REDS vs v2 Comparison...")
    try:
        reds_vs_v2.run_comparison_study(config)
        reds_vs_v2.analyze_comparison_results(config)
    except Exception as e:
        print("Comparison study failed:", e)
    print("\n3. Running ML Experiment...")
    try:
        ml_experiment.run_ml_experiment(config)
        ml_experiment.analyze_ml_results(config)
    except Exception as e:
        print("ML experiment failed:", e)
    print("\n4. Generating Convergence Plots...")
    try:
        convergence_plots.generate_all_convergence_plots(config)
    except Exception as e:
        print("Convergence plot generation failed:", e)
    print("\n5. Generating Advanced Plots...")
    try:
        advanced_plots.generate_all_advanced_plots(config)
    except Exception as e:
        print("Advanced plot generation failed:", e)
    print("\nAll experiments complete!")

if __name__ == "__main__":
    os.makedirs('results', exist_ok=True)
    main()
