import numpy as np

BRANIN_GLOBAL_MIN = 0.397887
HARTMANN3D_GLOBAL_MIN = -3.86278
ACKLEY2D_GLOBAL_MIN = 0.0
ROSENBROCK2D_GLOBAL_MIN = 0.0

def branin_function(x):
    x = np.asarray(x)
    x1, x2 = x[0], x[1]
    a = 1.0
    b = 5.1 / (4 * np.pi**2)
    c = 5.0 / np.pi
    r = 6.0
    s = 10.0
    t = 1.0 / (8 * np.pi)
    term1 = a * (x2 - b * x1**2 + c * x1 - r)**2
    term2 = s * (1 - t) * np.cos(x1)
    term3 = s
    return term1 + term2 + term3

def hartmann3d_function(x):
    x = np.asarray(x)
    alpha = np.array([1.0, 1.2, 3.0, 3.2])
    A = np.array([
        [3.0, 10.0, 30.0],
        [0.1, 10.0, 35.0],
        [3.0, 10.0, 30.0],
        [0.1, 10.0, 35.0]
    ])
    P = 1e-4 * np.array([
        [3689, 1170, 2673],
        [4699, 4387, 7470],
        [1091, 8732, 5547],
        [381, 5743, 8828]
    ])
    total = 0.0
    for i in range(4):
        inner = 0.0
        for j in range(3):
            inner += A[i, j] * (x[j] - P[i, j])**2
        total += alpha[i] * np.exp(-inner)
    return -total

def ackley2d_function(x):
    x = np.asarray(x)
    d = x.size
    a = 20.0
    b = 0.2
    c = 2 * np.pi
    sum1 = np.sum(x**2)
    sum2 = np.sum(np.cos(c * x))
    term1 = -a * np.exp(-b * np.sqrt(sum1 / d))
    term2 = -np.exp(sum2 / d)
    return term1 + term2 + a + np.e

def rosenbrock2d_function(x):
    x = np.asarray(x)
    return np.sum(100.0 * (x[1:] - x[:-1]**2)**2 + (1 - x[:-1])**2)

FUNCTION_CONFIGS = {
    'branin': {
        'bounds': [(-5.0, 10.0), (0.0, 15.0)],
        'dimension': 2,
        'global_min': BRANIN_GLOBAL_MIN,
        'grid_size': 50
    },
    'hartmann3d': {
        'bounds': [(0.0, 1.0), (0.0, 1.0), (0.0, 1.0)],
        'dimension': 3,
        'global_min': HARTMANN3D_GLOBAL_MIN,
        'grid_size': 20
    },
    'ackley2d': {
        'bounds': [(-5.0, 5.0), (-5.0, 5.0)],
        'dimension': 2,
        'global_min': ACKLEY2D_GLOBAL_MIN,
        'grid_size': 50
    },
    'rosenbrock2d': {
        'bounds': [(-2.0, 2.0), (-1.0, 3.0)],
        'dimension': 2,
        'global_min': ROSENBROCK2D_GLOBAL_MIN,
        'grid_size': 50
    }
}

def get_benchmark_function(name):
    mapping = {
        'branin': branin_function,
        'hartmann3d': hartmann3d_function,
        'ackley2d': ackley2d_function,
        'rosenbrock2d': rosenbrock2d_function
    }
    if name not in mapping:
        raise ValueError(f"Unknown function: {name}. Available: {list(mapping.keys())}")
    return mapping[name]
