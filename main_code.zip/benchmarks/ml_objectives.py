import numpy as np
from sklearn.svm import SVC
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score

class SVMObjectiveFunction:
    def __init__(self, c_bounds=(0.01, 100.0), gamma_bounds=(0.001, 1.0), test_size=0.3, random_state=None):
        self.c_bounds = c_bounds
        self.gamma_bounds = gamma_bounds
        self.test_size = test_size
        self.random_state = random_state
        data = load_breast_cancer()
        X = data['data']
        y = data['target']
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=self.test_size, random_state=self.random_state, stratify=y)
        scaler = StandardScaler()
        self.X_train = scaler.fit_transform(X_train)
        self.X_test = scaler.transform(X_test)
        self.y_train = y_train
        self.y_test = y_test

    def bounds(self):
        return [self.c_bounds, self.gamma_bounds]

    def evaluate(self, x):
        x = np.asarray(x)
        c = float(x[0])
        gamma = float(x[1])
        c = np.clip(c, self.c_bounds[0], self.c_bounds[1])
        gamma = np.clip(gamma, self.gamma_bounds[0], self.gamma_bounds[1])
        model = SVC(C=c, gamma=gamma, kernel='rbf')
        model.fit(self.X_train, self.y_train)
        preds = model.predict(self.X_test)
        acc = accuracy_score(self.y_test, preds)
        return acc
