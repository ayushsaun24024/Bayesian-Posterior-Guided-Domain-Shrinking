import matplotlib.pyplot as plt
import numpy as np
import os

def plot_method_comparison_boxplots(results, save_path):
    plt.figure()
    data = [v['stats']['all_regrets'] for v in results.values()]
    labels = [v['config']['function'] for v in results.values()]
    plt.boxplot(data, labels=labels)
    plt.title('Method Comparison: Simple Regret')
    plt.ylabel('Regret')
    plt.tight_layout()
    plt.savefig(save_path)
    plt.close()

def plot_mean_regret_bars(results, save_path):
    plt.figure()
    funcs = [v['config']['function'] for v in results.values()]
    means = [v['stats']['simple_regret_mean'] for v in results.values()]
    plt.bar(funcs, means)
    plt.title('Mean Simple Regret')
    plt.ylabel('Regret')
    plt.tight_layout()
    plt.savefig(save_path)
    plt.close()

def plot_win_loss_pie(win_counts, save_path):
    plt.figure()
    labels = list(win_counts.keys())
    sizes = list(win_counts.values())
    plt.pie(sizes, labels=labels, autopct='%1.1f%%', startangle=90)
    plt.title('Win/Loss Distribution')
    plt.tight_layout()
    plt.savefig(save_path)
    plt.close()

def plot_overall_comparison(results, save_path):
    plt.figure()
    methods = list(results.keys())
    means = [np.mean(v['stats']['simple_regret_mean']) for v in results.values()]
    stds = [v['stats']['simple_regret_std'] for v in results.values()]
    plt.bar(methods, means, yerr=stds, capsize=5)
    plt.ylabel('Mean Simple Regret ± Std')
    plt.title('Overall Method Comparison')
    plt.tight_layout()
    plt.savefig(save_path)
    plt.close()
