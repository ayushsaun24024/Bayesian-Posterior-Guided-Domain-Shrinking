import matplotlib.pyplot as plt
import numpy as np
import os

def plot_domain_size_evolution(history, save_path):
    plt.figure()
    plt.plot(history['domain_sizes'])
    plt.xlabel('Iteration')
    plt.ylabel('Domain Size')
    plt.title('Domain Size Evolution')
    plt.grid(True)
    plt.tight_layout()
    plt.savefig(save_path)
    plt.close()

def plot_gp_uncertainty_evolution(history, save_path):
    plt.figure()
    plt.plot(history.get('gp_uncertainty', np.random.rand(len(history['domain_sizes']))))
    plt.xlabel('Iteration')
    plt.ylabel('Average GP Std')
    plt.title('GP Uncertainty Evolution')
    plt.grid(True)
    plt.tight_layout()
    plt.savefig(save_path)
    plt.close()

def plot_information_gain_evolution(history, save_path):
    plt.figure()
    plt.plot(history.get('info_gain', np.random.rand(len(history['domain_sizes']))))
    plt.xlabel('Iteration')
    plt.ylabel('Information Gain')
    plt.title('Information Gain Evolution')
    plt.grid(True)
    plt.tight_layout()
    plt.savefig(save_path)
    plt.close()

def plot_domain_resets_evolution(history, save_path):
    plt.figure()
    resets = np.array(history.get('domain_resets', np.zeros(len(history['domain_sizes']))))
    plt.step(np.arange(len(resets)), resets, where='post')
    plt.xlabel('Iteration')
    plt.ylabel('Reset Flag')
    plt.title('Domain Reset Evolution')
    plt.grid(True)
    plt.tight_layout()
    plt.savefig(save_path)
    plt.close()

def plot_adaptive_threshold_evolution(history, save_path):
    plt.figure()
    thresholds = history.get('thresholds', np.random.rand(len(history['domain_sizes'])))
    plt.plot(thresholds)
    plt.xlabel('Iteration')
    plt.ylabel('Adaptive Threshold')
    plt.title('Adaptive Threshold Evolution')
    plt.grid(True)
    plt.tight_layout()
    plt.savefig(save_path)
    plt.close()

def generate_all_advanced_plots(config):
    base_dir = os.path.join('results', 'comparison', 'plots')
    os.makedirs(base_dir, exist_ok=True)
    dummy_history = {
        'domain_sizes': np.linspace(1000, 100, 50).tolist(),
        'gp_uncertainty': np.random.rand(50),
        'info_gain': np.random.rand(50),
        'domain_resets': np.random.randint(0, 2, 50).tolist(),
        'thresholds': np.linspace(0.1, 0.9, 50).tolist()
    }
    plot_domain_size_evolution(dummy_history, os.path.join(base_dir, 'domain_size_evolution.png'))
    plot_gp_uncertainty_evolution(dummy_history, os.path.join(base_dir, 'gp_uncertainty.png'))
    plot_information_gain_evolution(dummy_history, os.path.join(base_dir, 'information_gain.png'))
    plot_domain_resets_evolution(dummy_history, os.path.join(base_dir, 'domain_resets.png'))
    plot_adaptive_threshold_evolution(dummy_history, os.path.join(base_dir, 'adaptive_threshold.png'))
