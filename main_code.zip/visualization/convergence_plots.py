import matplotlib.pyplot as plt
import numpy as np
import os
from metrics.regret import compute_simple_regret, compute_cumulative_regret, compute_instantaneous_regret
from metrics.convergence import compute_convergence_rate, compute_sample_efficiency

def plot_simple_regret_vs_iterations(results, save_path):
    plt.figure()
    for label, data in results.items():
        iters = np.arange(len(data['simple_regret']))
        plt.plot(iters, data['simple_regret'], label=label)
    plt.xlabel('Iterations')
    plt.ylabel('Simple Regret')
    plt.title('Simple Regret vs Iterations')
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.savefig(save_path)
    plt.close()

def plot_cumulative_regret_vs_iterations(results, save_path):
    plt.figure()
    for label, data in results.items():
        iters = np.arange(len(data['cumulative_regret']))
        plt.plot(iters, data['cumulative_regret'], label=label)
    plt.xlabel('Iterations')
    plt.ylabel('Cumulative Regret')
    plt.title('Cumulative Regret vs Iterations')
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.savefig(save_path)
    plt.close()

def plot_instantaneous_regret_vs_iterations(results, save_path):
    plt.figure()
    for label, data in results.items():
        instantaneous = compute_instantaneous_regret(data['y_values'], data['global_optimum'])
        plt.plot(np.arange(len(instantaneous)), instantaneous, label=label)
    plt.xlabel('Iterations')
    plt.ylabel('Instantaneous Regret')
    plt.title('Instantaneous Regret vs Iterations')
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.savefig(save_path)
    plt.close()

def plot_convergence_rate_comparison(results, save_path):
    plt.figure()
    methods = []
    rates = []
    for label, data in results.items():
        rate = compute_convergence_rate(data['simple_regret'])
        methods.append(label)
        rates.append(rate)
    plt.bar(methods, rates)
    plt.xlabel('Method')
    plt.ylabel('Convergence Rate')
    plt.title('Convergence Rate Comparison')
    plt.tight_layout()
    plt.savefig(save_path)
    plt.close()

def plot_sample_efficiency(results, save_path):
    plt.figure()
    methods = []
    effs = []
    for label, data in results.items():
        eff = compute_sample_efficiency(data['simple_regret'])
        methods.append(label)
        effs.append(eff)
    plt.bar(methods, effs)
    plt.xlabel('Method')
    plt.ylabel('Samples to Threshold')
    plt.title('Sample Efficiency Comparison')
    plt.tight_layout()
    plt.savefig(save_path)
    plt.close()

def generate_all_convergence_plots(config):
    base_dir = os.path.join('results', 'comparison', 'plots')
    os.makedirs(base_dir, exist_ok=True)
    dummy_results = {
        'REDS': {'simple_regret': np.random.rand(50), 'cumulative_regret': np.cumsum(np.random.rand(50)), 'y_values': np.random.rand(50), 'global_optimum': 0.0},
        'BPG-DSv2': {'simple_regret': np.random.rand(50), 'cumulative_regret': np.cumsum(np.random.rand(50)), 'y_values': np.random.rand(50), 'global_optimum': 0.0}
    }
    plot_simple_regret_vs_iterations(dummy_results, os.path.join(base_dir, 'simple_regret.png'))
    plot_cumulative_regret_vs_iterations(dummy_results, os.path.join(base_dir, 'cumulative_regret.png'))
    plot_instantaneous_regret_vs_iterations(dummy_results, os.path.join(base_dir, 'instantaneous_regret.png'))
    plot_convergence_rate_comparison(dummy_results, os.path.join(base_dir, 'convergence_rate.png'))
    plot_sample_efficiency(dummy_results, os.path.join(base_dir, 'sample_efficiency.png'))
