import matplotlib.pyplot as plt
import numpy as np
import os

def plot_kfactor_ablation(ablation_data, save_path):
    plt.figure()
    for func, data in ablation_data.items():
        k_factors = data['k_factors']
        mean_regret = [np.mean(v) for v in data['regrets']]
        plt.plot(k_factors, mean_regret, marker='o', label=func)
    plt.xlabel('K-Factor')
    plt.ylabel('Mean Simple Regret')
    plt.title('K-Factor Ablation Study')
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.savefig(save_path)
    plt.close()

def plot_per_function_ablation(ablation_data, save_path):
    plt.figure(figsize=(8, 6))
    funcs = list(ablation_data.keys())
    mean_values = [np.mean(np.concatenate(v['regrets'])) for v in ablation_data.values()]
    plt.bar(funcs, mean_values)
    plt.title('Per-Function Ablation Performance')
    plt.ylabel('Mean Simple Regret')
    plt.tight_layout()
    plt.savefig(save_path)
    plt.close()
