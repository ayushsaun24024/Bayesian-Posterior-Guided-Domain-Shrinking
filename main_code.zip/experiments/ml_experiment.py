import yaml
import os
import numpy as np
from benchmarks.ml_objectives import SVMObjectiveFunction
from optimizers.bpgds_v2 import BPGDSv2Optimizer
from utils.data_utils import save_result_to_csv, create_result_directories, load_results_from_csv
from visualization.comparison_plots import plot_mean_regret_bars

def run_ml_experiment(config):
    create_result_directories('results')
    settings = config['ml_experiment']
    results_dir = os.path.join('results', 'ml_experiment')
    results_file = os.path.join(results_dir, settings['results_file'])
    dataset = settings['dataset']
    n_seeds = settings['n_seeds']
    print(f"Running ML experiment ({dataset}) with SVMObjectiveFunction...")
    objective = SVMObjectiveFunction(
        c_bounds=tuple(settings['c_bounds']),
        gamma_bounds=tuple(settings['gamma_bounds']),
        test_size=settings['test_size']
    )
    bounds = objective.bounds()
    k_factor = settings['k_factor']
    all_regrets = []
    for seed in range(n_seeds):
        optimizer = BPGDSv2Optimizer(objective.evaluate, bounds, config, seed=seed)
        result = optimizer.run(
            n_iterations=config['general']['n_epochs'],
            domain_size=config['general']['initial_domain_size'],
            k_factor=k_factor,
            save_file=results_file,
            seed=seed
        )
        all_regrets.append(result['simple_regret'][-1])
    return np.array(all_regrets)

def analyze_ml_results(config):
    print("Analyzing ML experiment results...")
    results_file = os.path.join('results', 'ml_experiment', config['ml_experiment']['results_file'])
    results = load_results_from_csv(results_file)
    plots_dir = os.path.join('results', 'ml_experiment', 'plots')
    os.makedirs(plots_dir, exist_ok=True)
    plot_mean_regret_bars(results, os.path.join(plots_dir, 'ml_mean_regret.png'))
