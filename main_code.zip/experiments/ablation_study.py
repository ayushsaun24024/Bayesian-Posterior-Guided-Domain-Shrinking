import yaml
import os
import numpy as np
from benchmarks.synthetic import get_benchmark_function, FUNCTION_CONFIGS
from optimizers.bpgds_v2 import BPGDSv2Optimizer
from utils.data_utils import save_result_to_csv, create_result_directories
from visualization.ablation_plots import plot_kfactor_ablation, plot_per_function_ablation

def run_ablation_study(config):
    create_result_directories('results')
    settings = config['ablation_study']
    results_dir = os.path.join('results', 'ablation')
    results_file = os.path.join(results_dir, settings['results_file'])
    functions = settings['functions']
    k_factors = settings['k_factors']
    n_seeds = settings['seeds_per_config']
    all_results = {}

    for func_name in functions:
        func = get_benchmark_function(func_name)
        bounds = FUNCTION_CONFIGS[func_name]['bounds']
        print(f"Running ablation for {func_name}")
        per_func = {'k_factors': [], 'regrets': []}
        for k in k_factors:
            regrets = []
            for seed in range(n_seeds):
                optimizer = BPGDSv2Optimizer(func, bounds, config, seed=seed)
                result = optimizer.run(
                    n_iterations=config['general']['n_epochs'],
                    n_initial=5,
                    domain_size=config['general']['initial_domain_size'],
                    k_factor=k,
                    save_file=results_file,
                    seed=seed
                )
                regrets.append(result['simple_regret'][-1])
            per_func['k_factors'].append(k)
            per_func['regrets'].append(regrets)
        all_results[func_name] = per_func

    plot_kfactor_ablation(all_results, os.path.join(results_dir, 'plots', 'kfactor_ablation.png'))
    plot_per_function_ablation(all_results, os.path.join(results_dir, 'plots', 'per_function_ablation.png'))
    return all_results

def analyze_ablation_results(config):
    print("Analyzing ablation study results...")
    results_dir = os.path.join('results', 'ablation', 'plots')
    if not os.path.exists(results_dir):
        print("No plots found. Please run the ablation study first.")
    else:
        print("Ablation plots generated successfully.")
