import yaml
import os
import numpy as np
from benchmarks.synthetic import get_benchmark_function, FUNCTION_CONFIGS
from optimizers.reds import REDSOptimizer
from optimizers.bpgds_v2 import BPGDSv2Optimizer
from utils.data_utils import save_result_to_csv, create_result_directories, load_results_from_csv
from visualization.comparison_plots import plot_method_comparison_boxplots, plot_mean_regret_bars, plot_overall_comparison

def run_comparison_study(config):
    create_result_directories('results')
    settings = config['comparison_study']
    results_dir = os.path.join('results', 'comparison')
    results_file = os.path.join(results_dir, settings['results_file'])
    functions = settings['functions']
    n_seeds = settings['n_seeds']
    all_results = {}

    for func_name in functions:
        func = get_benchmark_function(func_name)
        bounds = FUNCTION_CONFIGS[func_name]['bounds']
        k_factor = settings['optimal_k_factors'][func_name]
        print(f"Comparing REDS vs BPG-DSv2 for {func_name}")
        reds_regrets = []
        v2_regrets = []
        for seed in range(n_seeds):
            reds = REDSOptimizer(func, bounds, config, seed=seed)
            reds_result = reds.run(
                n_iterations=config['general']['n_epochs'],
                domain_size=config['general']['initial_domain_size'],
                save_file=results_file,
                seed=seed
            )
            v2 = BPGDSv2Optimizer(func, bounds, config, seed=seed)
            v2_result = v2.run(
                n_iterations=config['general']['n_epochs'],
                domain_size=config['general']['initial_domain_size'],
                k_factor=k_factor,
                save_file=results_file,
                seed=seed
            )
            reds_regrets.append(reds_result['simple_regret'][-1])
            v2_regrets.append(v2_result['simple_regret'][-1])
        all_results[func_name] = {
            'REDS': np.array(reds_regrets),
            'BPG-DSv2': np.array(v2_regrets)
        }
    return all_results

def analyze_comparison_results(config):
    print("Analyzing REDS vs BPG-DSv2 comparison...")
    results_file = os.path.join('results', 'comparison', config['comparison_study']['results_file'])
    results = load_results_from_csv(results_file)
    plots_dir = os.path.join('results', 'comparison', 'plots')
    plot_method_comparison_boxplots(results, os.path.join(plots_dir, 'boxplot.png'))
    plot_mean_regret_bars(results, os.path.join(plots_dir, 'mean_regret.png'))
    plot_overall_comparison(results, os.path.join(plots_dir, 'overall_comparison.png'))
