import numpy as np

def compute_convergence_rate(simple_regrets):
    if len(simple_regrets) < 2:
        return 0.0
    diffs = np.diff(simple_regrets)
    rate = -np.mean(diffs[diffs < 0]) if np.any(diffs < 0) else 0.0
    return rate

def compute_sample_efficiency(simple_regrets, threshold=1e-3):
    below_threshold = np.where(np.array(simple_regrets) <= threshold)[0]
    if len(below_threshold) == 0:
        return len(simple_regrets)
    return below_threshold[0] + 1

def find_threshold_iteration(simple_regrets, threshold=1e-3):
    below = np.where(np.array(simple_regrets) <= threshold)[0]
    return below[0] if len(below) > 0 else None
