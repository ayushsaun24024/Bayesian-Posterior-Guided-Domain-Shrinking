import numpy as np
from scipy.stats import ttest_ind

def run_ttest(data1, data2):
    stat, pvalue = ttest_ind(data1, data2, equal_var=False)
    return stat, pvalue

def compute_improvement(mean_a, mean_b):
    if mean_b == 0:
        return 0.0
    return ((mean_b - mean_a) / abs(mean_b)) * 100.0

def determine_winner(results_a, results_b, alpha=0.05):
    stat, pvalue = run_ttest(results_a, results_b)
    if pvalue < alpha:
        if np.mean(results_a) < np.mean(results_b):
            return "A", pvalue
        else:
            return "B", pvalue
    return "None", pvalue
