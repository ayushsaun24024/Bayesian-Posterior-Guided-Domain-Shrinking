import numpy as np

def compute_simple_regret(best_values, global_optimum):
    regrets = np.abs(np.array(best_values) - global_optimum)
    return regrets

def compute_cumulative_regret(all_values, global_optimum):
    values = np.asarray(all_values)
    regrets = np.maximum(0.0, global_optimum - values)
    cumulative = np.cumsum(regrets)
    return cumulative

def compute_instantaneous_regret(values, global_optimum):
    values = np.asarray(values)
    regrets = np.maximum(0.0, global_optimum - values)
    return regrets
